$(document).ready(function(){
    $('.delete_btn').click(delete_clicked);
});

function delete_clicked(event) {
    event.preventDefault();

    var id = $(this).data('userId');
    //alert( "Enable" + id );
    $.ajax({
        type: "POST",
        url: "/api/user/delete_user",
        data: {
            user_id: id
        },
        dataType: "text",
        success: function (data) {
            try {
                var data_json = $.parseJSON(data);
            } catch(e) {
                alert(data);
                return;
            }
            if (data_json.res === "ok") {
                location.reload();
            } else {
                alert(data);
            }
        }
    });
}