$(document).ready(function(){
    $('.create_form').submit(save_clicked);
});

function save_clicked(event) {
    event.preventDefault();
    var form = $('.create_form')
    var formData = form.serialize()

    //alert( "Enable" + id );
    $.ajax({
        type: "POST",
        url: form.attr('action'),
        data: formData,
        async: false,
        cache: false,
        processData: false,
        success: function (data) {
                location.href = "/html/privileges/privileges_list.html"
        }
    });
}