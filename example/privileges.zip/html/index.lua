function ()
    local cursor, errorString = db:execute([[SELECT row_id, user_id, privilege_id FROM m_privileges_User_privilege]])
    if cursor == nil then
        return {error=errorString, er2="cursor is nil"}
    end
    local row = cursor:fetch({}, 'a')
    if row == nil then
        return {error='empty result'}
    end
    local res = {}
    res.user_privileges = {}
    local n = 0
    while row do
        n = n + 1
        local t = {}
        local uid = row.user_id
        local pid = row.privilege_id

        local cr, err = db:execute(string.format([[SELECT first_name, last_name, middle_name FROM m_user_User WHERE id=%d]], uid))
        local ur = cr:fetch({}, 'a')
        if ur == nil then return {res="error", error="no user by id"} end
        local user_str = ur.last_name .. " " .. ur.first_name .. " " .. ur.middle_name

        cr, err = db:execute(string.format([[SELECT name FROM m_privileges_Privilege WHERE id=%d]], pid))
        ur = cr:fetch({}, 'a')
        if ur == nil then return {res="error", error="no privilege by id"} end
        local privilege_str = ur.name

        t.id = row.row_id
        t.user = user_str
        t.privilege = privilege_str

        res.user_privileges[n] = t
        row = cursor:fetch({}, 'a')
    end

    return res
end