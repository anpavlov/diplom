function ()
    local res = {}
    local cursor, errorString = db:execute([[SELECT id, first_name, last_name, middle_name, birth_date FROM m_user_User]])
    if cursor == nil then
        return {error=errorString, er2="cursor is nil"}
    end
    local row = cursor:fetch({}, 'a')
    res.users = {}
    if row ~= nil then
        local n = 0
        while row do
            n = n + 1
            local t = {}
            t.id = row.id
            t.name = row.last_name .. " " .. row.first_name .. " " .. row.middle_name .. " " .. row.birth_date
            res.users[n] = t
            row = cursor:fetch({}, 'a')
        end
    end


    cursor, errorString = db:execute([[SELECT id, name FROM m_privileges_Privilege]])
    if cursor == nil then
        return {error=errorString, er2="cursor is nil"}
    end
    row = cursor:fetch({}, 'a')
    res.privileges = {}
    if row ~= nil then
        local n = 0
        while row do
            n = n + 1
            local t = {}
            t.id = row.id
            t.name = row.name
            res.privileges[n] = t
            row = cursor:fetch({}, 'a')
        end
    end

    return res
end