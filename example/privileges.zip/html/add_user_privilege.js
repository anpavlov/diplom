$(document).ready(function(){
    $('.create_form').submit(save_clicked);
});

function save_clicked(event) {
    event.preventDefault();
    var form = $('.create_form')
    var formData = form.serialize()

    //alert( "Enable" + id );
    $.ajax({
        type: "POST",
        url: form.attr('action'),
        data: formData,
        async: false,
        cache: false,
        processData: false,
        dataType: "text",
        success: function (data) {
            try {
                var data_json = $.parseJSON(data);
            } catch(e) {
                alert(data);
                return;
            }
            if (data_json.res === "ok") {
                location.href = "/html/privileges/index.html"
            } else {
                alert(data_json.error);
            }
        }
    });
}