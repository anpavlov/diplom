$(document).ready(function(){
    $('.delete_btn').click(delete_clicked);
});

function delete_clicked(event) {
    event.preventDefault();

    var id = $(this).data('privilegeId');
    //alert( "Enable" + id );
    $.ajax({
        type: "POST",
        url: "/api/privileges/delete_privilege",
        data: {
            privilege_id: id
        },
        dataType: "text",
        success: function (data) {
            try {
                var data_json = $.parseJSON(data);
            } catch(e) {
                alert(data);
                return;
            }
            if (data_json.res === "ok") {
                location.reload();
            } else {
                alert(data);
            }
        }
    });
}