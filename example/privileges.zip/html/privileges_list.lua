function ()
    local cursor, errorString = db:execute([[SELECT id, name, description FROM m_privileges_Privilege]])
    if cursor == nil then
        return {error=errorString, er2="cursor is nil"}
    end
    local row = cursor:fetch({}, 'a')
    if row == nil then
        return {error='empty result'}
    end
    local res = {}
    res.privileges = {}
    local n = 0
    while row do
        n = n + 1
        local t = {}
        t.id = row.id
        t.name = row.name
        t.description = row.description
        res.privileges[n] = t
        row = cursor:fetch({}, 'a')
    end

    return res
end