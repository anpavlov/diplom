function ()
    local id = tonumber(args.privilege_id[0])
    if id == nil then
        error("not enough data in arguments")
    end

    local status, errorString = db:execute(string.format(
                                            [[DELETE FROM m_privileges_Privilege WHERE id=%d]],
                                            id))
    if status == 0 then
        return {res="error", error=errorString}
    end

    return {res="ok"}
end