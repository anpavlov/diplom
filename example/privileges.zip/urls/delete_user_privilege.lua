function ()
    local id = tonumber(args.user_privilege_id[0])
    if id == nil then
        error("not enough data in arguments")
    end

    local status, errorString = db:execute(string.format(
                                            [[DELETE FROM m_privileges_User_privilege WHERE row_id=%d]],
                                            id))
    if status == 0 then
        return {res="error", error=errorString}
    end

    return {res="ok"}
end