function ()
    local uid = tonumber(args.user_id[0])
    local pid = tonumber(args.privilege_id[0])

    if uid == nil or pid == nil then
        error("not enough data in arguments")
    end

    local cursor, errorString = db:execute(string.format([[SELECT DISTINCT user_id, privilege_id FROM m_privileges_User_privilege WHERE user_id=%d]], uid))
    if cursor == nil then
        return {error=errorString, res="error"}
    end
    local row = cursor:fetch({}, 'a')
    if row ~= nil then
        local n = 0
        while row do
            n = n + 1
            row = cursor:fetch({}, 'a')
        end

        if n >= settings.max_privileges then
            return {res="err", error="max privileges for this user" }
        end
    end

    local status, errorString = db:execute(string.format(
                                            [[INSERT INTO m_privileges_User_privilege (user_id, privilege_id) VALUES (%d, %d)]],
                                            uid, pid))
    if status == 0 then
        return {error=errorString, res="error"}
    end

    return {res="ok"}
end