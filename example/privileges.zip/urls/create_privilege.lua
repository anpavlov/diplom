function ()
--    local id = tonumber(args.user_id[0])
    local name = args.name[0]
    local description = args.description[0]
    if name == nil or description == nil then
        error("not enough data in arguments")
    end

    local status, errorString = db:execute(string.format(
                                            [[INSERT INTO m_privileges_Privilege (name, description) VALUES (%q, %q)]],
                                            name, description))
    if status == 0 then
        return {error=errorString, res="error"}
    end
    local id = db:getlastautoid()
    local res = {}
    res.id = id
    res.name = name
    res.description = description

    return res
end